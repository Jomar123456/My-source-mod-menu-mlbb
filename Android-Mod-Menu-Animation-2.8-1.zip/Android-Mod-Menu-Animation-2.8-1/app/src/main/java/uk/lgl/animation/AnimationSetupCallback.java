package uk.lgl.animation;

import uk.lgl.modmenu.FloatingModMenuService;

public interface AnimationSetupCallback {
    public void onSetupAnimation(TitanicTextView titanicTextView);
    public void onSetupAnimation(TitanicButton Button);
}

